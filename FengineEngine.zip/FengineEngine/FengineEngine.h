#pragma once

namespace FengineEngine {
	extern int init();
}