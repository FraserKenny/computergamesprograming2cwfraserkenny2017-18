

namespace Bengine {
    extern int init();
}