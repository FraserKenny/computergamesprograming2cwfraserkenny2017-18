#include <SDL\SDL.h>
#include <GL\glew.h>

#include "FengineEngine.h"

namespace FengineEngine {
	int init()
	{
		//Initialise SDL
		SDL_Init(SDL_INIT_EVERYTHING);

		//tell openg gl to double buff this gets helps get rid of screen flickering, apparently it should go here
		SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

		return 0;
	}
}