#pragma once
//This file holds some global error functions

#include <string>

namespace FengineEngine {

    extern void fatalError(std::string errorString);

}