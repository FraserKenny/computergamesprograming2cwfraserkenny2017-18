#pragma once
#include <string>
namespace FengineEngine {

	extern void fatalError(std::string errorString);

}
