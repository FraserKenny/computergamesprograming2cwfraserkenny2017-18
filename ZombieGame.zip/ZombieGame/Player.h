#pragma once

#include "Human.h"
#include <FengineEngine/InputManager.h>
#include <FengineEngine/Camera2D.h>
#include "Bullet.h"

class Gun;

class Player : public Human
{
public:
    Player();
    ~Player();

    void init(float speed, glm::vec2 pos, FengineEngine::InputManager* inputManager, FengineEngine::Camera2D* camera, std::vector<Bullet>* bullets);

    void addGun(Gun* gun);

    void update(const std::vector<std::string>& levelData,
                std::vector<Human*>& humans,
                std::vector<Zombie*>& zombies,
                float deltaTime) override;
private:
	FengineEngine::InputManager* _inputManager;

    std::vector<Gun*> _guns;
    int _currentGunIndex;

	FengineEngine::Camera2D* _camera;
    std::vector<Bullet>* _bullets;

};

