#include "MainGame.h"

#include <FengineEngine/Errors.h>
#include <FengineEngine/ResourceManager.h>

#include <iostream>
#include <string>


MainGame::MainGame() : _screenHeight(768),
						_screenWidth(1024),
						_time(0.0f),
						_gameState(GameState::PLAY),
						_maxFps(60.0f)
{
	_camera.init(_screenWidth, _screenHeight);
}


MainGame::~MainGame()
{

}
//this runs the game
void MainGame::run()
{
	initSystems();

/*temp sprite init
		_sprites.push_back(new FengineEngine::Sprite());
		_sprites.back()->init(0.0f, 0.0f, _screenWidth / 2, _screenHeight / 2, "Textures/player_plane");

//	_playerTexture = ImageLoader::loadPNG("Textures/player_plane"); */

//only returns when game ends
	gameLoop();

}

void MainGame::initSystems()
{
	FengineEngine::init();

	_window.create("Fraser'sGameEngine", _screenWidth, _screenHeight, 0);

	initShaders();

	_spriteBatch.init();
	_fpsLimiter.init(_maxFps);
}

void MainGame::initShaders()
{
	_colorProgram.compileShaders("shaders/vert", "shaders/frag");
	_colorProgram.addAttribute("vertexPosition");
	_colorProgram.addAttribute("vertexColor");
	_colorProgram.addAttribute("vertexUV");
	_colorProgram.linkShaders();
}

//this is the main game
void MainGame::gameLoop()
{
//will loop till game state is exit
	while (_gameState != GameState::EXIT)
	{
//used for frame time measurment
		_fpsLimiter.begin();

		processInput();
		_time += 0.01;

		_camera.update();

//ipdate all bullets
		for (int i = 0; i < _bulets.size();)
		{
			if (_bulets[i].update() == true)
			{
				_bulets[i] = _bulets.back();
				_bulets.pop_back();
			}
			else
			{
				i++;
			}
		}

		drawGame();

		_fps = _fpsLimiter.end();

//print every 10 frames
		static int frameCounter = 0;
		frameCounter++;
		if (frameCounter == 10)
		{
			std::cout << _fps << std::endl;
			frameCounter = 0;
		}
	}
}

void MainGame::processInput()
{
	SDL_Event evnt;

	const float speed = 10.0f;
	const float scaleSpeed = 0.1f;

	while (SDL_PollEvent(&evnt))
	{
		switch (evnt.type)
		{
		case SDL_QUIT:
			_gameState = GameState::EXIT;
			break;
			//was used to display mouse motion, i dont actualy need it
		case SDL_KEYDOWN:
			_inputManager.pressKey(evnt.key.keysym.sym);
			break;
		case SDL_KEYUP:
			_inputManager.releaseKey(evnt.key.keysym.sym);
			break;
		case SDL_MOUSEBUTTONDOWN:
			_inputManager.pressKey(evnt.button.button);
			break;
		case SDL_MOUSEBUTTONUP:
			_inputManager.releaseKey(evnt.button.button);
			break;
		case SDL_MOUSEMOTION:
			_inputManager.setMouseCoords(evnt.motion.x, evnt.motion.y);
			break;
		}

	}
	if (_inputManager.isKeyPressed(SDLK_w))
	{
		_camera.setPosition(_camera.getPosition() + glm::vec2(0.0, speed));
	}
	if (_inputManager.isKeyPressed(SDLK_s))
	{
		_camera.setPosition(_camera.getPosition() + glm::vec2(0.0, -speed));
	}
	if (_inputManager.isKeyPressed(SDLK_a))
	{
		_camera.setPosition(_camera.getPosition() + glm::vec2(-speed, 0.0));
	}
	if (_inputManager.isKeyPressed(SDLK_d))
	{
		_camera.setPosition(_camera.getPosition() + glm::vec2(speed, 0.0));
	}
	if (_inputManager.isKeyPressed(SDLK_q))
	{
		_camera.setScale(_camera.getScale() + scaleSpeed);
	}
	if (_inputManager.isKeyPressed(SDLK_e))
	{
		_camera.setScale(_camera.getScale() - scaleSpeed);
	}
	if (_inputManager.isKeyPressed(SDL_BUTTON_LEFT))
	{
		glm::vec2 mouseCoords = _inputManager.getMouseCoords();
		mouseCoords = _camera.convertScreenToWorld(mouseCoords);

		glm::vec2 playerPosition(0.0f);
		glm::vec2 direction = mouseCoords - playerPosition;
		direction = glm::normalize(direction);

		_bulets.emplace_back(playerPosition, direction, 10.0f, 20);
	}
}
//draw game using opengl
void MainGame::drawGame()
{

//set base depth to 1.0
	glClearDepth(1.0);
//clear dapth and color buffer using a bitwise op
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
/*
//using immediate mode will not actually be used later
	glEnableClientState(GL_COLOR_ARRAY);
	glBegin(GL_TRIANGLES);
	glColor3f(1.0f,0.0f,1.0f);
	glVertex2f(-1, -1);
	glVertex2f(0, -1);
	glVertex2f(0, 0);

	glEnd();
//end of immediate mode
*/
//enable the shader
	_colorProgram.use();
//using texture unit 0
	glActiveTexture(GL_TEXTURE0);
//get uniform location
	GLint textureLocation = _colorProgram.getUniformLocation("playerTexture");
//tell shader texture is in tex unit 0
	glUniform1i(textureLocation, 0);

//need to comment these out when a shader doesnt use them cause it doesnt work for reasons i'll put in documentation
//but simply its a constanly changing time variable
	//GLuint timeLocation = _colorProgram.getUnifromLocation("time");
	//glUniform1f(timeLocation, _time);

//set the cameraMatrix
	GLuint pLocation = _colorProgram.getUniformLocation("P");
	glm::mat4 cameraMatrix = _camera.getCameraMatrix();

	glUniformMatrix4fv(pLocation, 1, GL_FALSE, &(cameraMatrix[0][0]));

	_spriteBatch.begin();

	glm::vec4 pos(0.0f, 0.0f, 50.0f, 50.0f);
	glm::vec4 uv(0.0f, 0.0f, 1.0f, 1.0f);
	FengineEngine::GLTexture texture = FengineEngine::ResourceManager::getTexture("Textures/player_plane");
	FengineEngine::ColorRGBA8 color;
	color.r = 255;
	color.g = 255;
	color.b = 125;
	color.a = 255;
	_spriteBatch.draw(pos, uv, texture.id, 0.0f, color);

//draw bullets
	for (int i = 0; i < _bulets.size(); i++)
	{
		_bulets[i].draw(_spriteBatch);
	}

	_spriteBatch.end();
	_spriteBatch.renderBatch();

/*Not really gonna use this when ive got better methods like sprite batch
//draw our sprite/s
	for (int i = 0; i < _sprites.size(); i++)
	{
		_sprites[i]->draw();
	}
*/
	glBindTexture(GL_TEXTURE_2D, 0);
	_colorProgram.unuse();

//swap our window buffers
	_window.swapBuffer();
}
