#pragma once

#include <glm/glm.hpp>
#include <FengineEngine\SpriteBatch.h>

class Bulet
{
public:
	Bulet(glm::vec2 pos, glm::vec2 dir, float speed, int lifeTime);
	~Bulet();

	void draw(FengineEngine::SpriteBatch& spriteBatch);
//returns true when time of travel is up
	bool update();

private:
	int _lifeTime;
	float _speed;
	glm::vec2 _direction;
	glm::vec2 _position;
};

