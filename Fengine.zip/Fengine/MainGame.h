#pragma once
#include <FengineEngine/GlslProgram.h>
#include <FengineEngine/Sprite.h>
#include <FengineEngine/GlTexture.h>
#include <FengineEngine/Window.h>
#include <FengineEngine/FengineEngine.h>
#include <FengineEngine/Camera2D.h>
#include <FengineEngine/SpriteBatch.h>
#include <FengineEngine/InputManager.h>
#include <FengineEngine/Timing.h>

#include <SDL/SDL.h>
#include <GL/glew.h>
#include <vector>

#include "Bulet.h"

enum class GameState {PLAY, EXIT};

class MainGame
{
public:
	MainGame();
	~MainGame();

	void run();
	void drawGame();

private:

	void initShaders();
	void initSystems();
	void gameLoop();
	void processInput();
	
	FengineEngine::Window _window;
	GameState _gameState;

	int _screenWidth;
	int _screenHeight;
	float _time;

//	std::vector <FengineEngine::Sprite*> _sprites;
//	Sprite _sprite;
	FengineEngine::GLSLProgram _colorProgram;
	FengineEngine::Camera2D _camera;
	FengineEngine::SpriteBatch _spriteBatch;
	FengineEngine::InputManager _inputManager;
	FengineEngine::FpsLimiter _fpsLimiter;

	std::vector<Bulet> _bulets;

	float _fps;

	float _maxFps;
};

